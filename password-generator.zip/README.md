# Password Generator

A secure password generator built with HTML, CSS, and JavaScript.

## Features
- Choose password length
- Include lowercase, uppercase, numbers, symbols
- Copy password to clipboard
- Secure randomness using Crypto API

## How to Run
Just open `index.html` in your browser.
